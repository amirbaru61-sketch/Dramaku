# DramaKita — Prototipe Android tahap 1

DramaKita adalah prototipe aplikasi Android native dengan Kotlin dan Jetpack Compose. Ini proyek tahap pertama: metadata drama berasal dari data lokal, favorit tersimpan di HP, dan pemutar memakai video demo publik melalui internet. Belum ada login, backend, iklan, pembayaran, atau langganan.

## Fitur yang sudah disiapkan di kode

- Beranda dengan poster ilustratif, kategori, pilihan hari ini, dan daftar drama terbaru.
- Halaman detail berisi sinopsis, kategori, jumlah episode, tombol mulai menonton, dan tombol favorit.
- Pemutar video berbasis AndroidX Media3 / ExoPlayer dengan tombol putar/jeda, indikator loading, pesan video gagal, deteksi koneksi, tombol coba lagi, dan pemilih episode.
- Pencarian berdasarkan judul, kategori, atau sinopsis.
- Favorit lokal lewat `SharedPreferences`, tidak memerlukan akun.
- Navigasi bawah yang sederhana untuk Beranda, Cari, dan Favorit.
- Unit test sederhana untuk memeriksa data contoh.

## Penting tentang konten demo

Judul dan sinopsis yang terlihat di aplikasi adalah data contoh buatan untuk prototipe, bukan katalog drama sungguhan. Untuk menguji pemutar, semua episode sementara menunjuk ke **Big Buck Bunny** dari Blender Foundation. Itu film animasi demo, bukan drama vertikal; aplikasi memotong tampilan video lanskap agar memenuhi layar vertikal.

Film Big Buck Bunny dirilis dengan lisensi Creative Commons Attribution 3.0. Kredit ditampilkan di halaman pemutar. Informasi lisensi: https://peach.blender.org/about/ dan halaman unduh resmi: https://peach.blender.org/download/ . Tautan video publik bisa berubah atau tidak tersedia; aplikasi menampilkan pesan kesalahan dan tombol coba lagi bila gagal.

## Arti file utama (bahasa sederhana)

| File | Fungsinya |
|---|---|
| `app/src/main/java/id/dramakita/app/MainActivity.kt` | Titik awal saat aplikasi dibuka. |
| `ui/DramaKitaApp.kt` | Mengatur halaman yang sedang terlihat, tombol navigasi, dan perpindahan dari detail ke pemutar. |
| `data/Drama.kt` | Bentuk data untuk satu drama dan satu episode. |
| `data/DramaRepository.kt` | Daftar contoh judul, sinopsis, poster, episode, dan tautan video demo. |
| `data/FavoritesStore.kt` | Membaca/menyimpan daftar favorit di penyimpanan HP. |
| `ui/screens/HomeScreen.kt` | Tampilan beranda dan drama terbaru. |
| `ui/screens/SearchScreen.kt` | Kolom pencarian dan hasilnya. |
| `ui/screens/FavoritesScreen.kt` | Daftar drama favorit. |
| `ui/screens/DetailScreen.kt` | Detail drama dan tombol mulai menonton. |
| `ui/screens/PlayerScreen.kt` | Pemutar video, daftar episode, status jaringan, dan pesan kesalahan. |
| `ui/components/DramaPosterCard.kt` | Komponen kartu/poster yang dipakai ulang. |
| `ui/theme/DramaKitaTheme.kt` | Warna dan tema gelap aplikasi. |
| `app/build.gradle.kts` | Dependensi dan pengaturan build modul aplikasi. |
| `.github/workflows/build-android.yml` | Otomatis menjalankan tes dan membuat APK debug di GitHub Actions. |

## Cara membuat APK jika hanya menggunakan HP Android

### Pilihan A — build langsung di HP

1. Unduh lalu ekstrak ZIP proyek ini di HP.
2. Buka proyek melalui IDE Android yang mendukung Kotlin, Jetpack Compose, Gradle, dan Android SDK. Salah satu proyek IDE Android yang masih menyediakan build di perangkat adalah [Code on the Go](https://appdevforall.org/code-on-the-go/); pastikan IDE tersebut dapat memasang Android SDK API 36 di HP kamu.
3. Pilih **Open existing project** lalu arahkan ke folder `DramaKita` yang berisi `settings.gradle.kts` (bukan folder `app` di dalamnya).
4. Tunggu sinkronisasi Gradle. Jalankan tes dan build `assembleDebug` bila IDE menyediakan terminal/tasks, atau gunakan tombol build/run pada IDE.
5. Setelah build sukses, APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Saya belum menguji kompatibilitas proyek ini dengan IDE Android tertentu. Build langsung di HP bergantung pada dukungan SDK API 36, JDK 17, dan library yang harus diunduh.

### Pilihan B — build otomatis lewat GitHub Actions

Pilihan ini menggunakan server GitHub untuk build dan tes. Kamu perlu akun GitHub dan koneksi internet.

1. Buat repositori GitHub baru dan unggah **isi folder proyek yang sudah diekstrak** — pastikan `settings.gradle.kts`, `build.gradle.kts`, folder `app`, dan folder `.github` ikut diunggah, bukan hanya ZIP-nya.
2. Buka tab **Actions** pada repositori. Workflow bernama **Build DramaKita APK** akan berjalan otomatis setelah file didorong ke repositori; bila belum berjalan, pilih workflow itu lalu tekan **Run workflow**.
3. Setelah job selesai dengan status hijau, buka hasil run, cari **Artifacts**, lalu unduh `DramaKita-debug-apk`.
4. Ekstrak artifact tersebut dan pasang `app-debug.apk` di HP. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

Jika build merah/gagal, buka run tersebut dan salin **pesan error lengkap mulai dari bagian yang menyebut `FAILURE`, `e:`, atau `Execution failed`**. Jangan menebak penyebabnya; perbaikan harus berdasarkan pesan error yang benar-benar muncul.

## Build dari terminal / Android IDE

Dengan JDK 17 dan Android SDK API 36 terpasang, jalankan dari folder proyek:

```sh
./gradlew testDebugUnitTest assembleDebug
```

Di Windows:

```bat
gradlew.bat testDebugUnitTest assembleDebug
```

Wrapper akan mengunduh komponen Gradle yang dibutuhkan saat pertama kali dijalankan. Build pertama memerlukan internet dan ruang penyimpanan untuk mengunduh Gradle, Android SDK, serta library.

Lokasi APK debug setelah build sukses:

`app/build/outputs/apk/debug/app-debug.apk`

## Checklist tes prototipe

- Beranda terbuka dan kartu drama dapat dipilih.
- Halaman detail menampilkan sinopsis dan jumlah episode.
- Tombol mulai menonton membuka pemutar.
- Tombol tengah dapat memulai dan menjeda video.
- Pemilihan EP 1–EP 5 memulai ulang video demo untuk episode yang dipilih.
- Mematikan internet saat di halaman pemutar menampilkan pesan koneksi; setelah internet kembali, tombol coba lagi dapat digunakan.
- Pencarian menemukan judul, kategori, atau kata di sinopsis.
- Menambah favorit, pindah halaman, dan membuka ulang aplikasi tidak menghapus favorit.
- `testDebugUnitTest` selesai tanpa gagal.

## Status pengujian

Proyek ini disiapkan di lingkungan kerja yang **tidak memiliki Android SDK maupun Gradle terpasang**. Karena itu, build Android dan uji jalan di perangkat **belum dapat saya jalankan dari lingkungan ini**. Workflow GitHub Actions disertakan untuk menjalankan tes dan build nyata; jangan menganggap APK berhasil dibuat sampai workflow atau build lokal benar-benar sukses.
