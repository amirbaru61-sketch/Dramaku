package id.dramakita.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.dramakita.app.data.Drama
import id.dramakita.app.data.DramaRepository
import id.dramakita.app.ui.components.DramaRowItem

@Composable
fun SearchScreen(
    favoriteIds: Set<String>,
    onDramaClick: (Drama) -> Unit,
    onFavoriteClick: (Drama) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val matches = DramaRepository.dramas.filter { drama ->
        query.isBlank() ||
            drama.title.contains(query, ignoreCase = true) ||
            drama.category.contains(query, ignoreCase = true) ||
            drama.synopsis.contains(query, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0F15))
            .padding(horizontal = 18.dp)
            .padding(top = 22.dp)
    ) {
        Text("Cari drama", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text("Temukan cerita yang cocok untukmu.", modifier = Modifier.padding(top = 5.dp), color = Color(0xFFBDBBCB), fontSize = 13.sp)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp),
            placeholder = { Text("Cari judul atau kategori…", color = Color(0xFF8D8B9B)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Cari", tint = Color(0xFFFF8EAA)) },
            singleLine = true,
            shape = androidx.compose.foundation.shape.RoundedCornerShape(15.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFFFF5C83),
                unfocusedBorderColor = Color(0xFF343541),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = Color(0xFFFF5C83)
            )
        )
        Text("${matches.size} drama ditemukan", color = Color(0xFFBDBBCB), fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
        LazyColumn(
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (matches.isEmpty()) {
                item {
                    Text("Belum ada drama yang cocok. Coba kata lain.", color = Color(0xFFBDBBCB), modifier = Modifier.padding(vertical = 20.dp))
                }
            }
            items(matches, key = { it.id }) { drama ->
                DramaRowItem(
                    drama = drama,
                    isFavorite = drama.id in favoriteIds,
                    onClick = { onDramaClick(drama) },
                    onFavoriteClick = { onFavoriteClick(drama) }
                )
            }
        }
    }
}
