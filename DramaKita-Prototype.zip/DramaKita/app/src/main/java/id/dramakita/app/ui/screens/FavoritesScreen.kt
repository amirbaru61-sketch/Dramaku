package id.dramakita.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.dramakita.app.data.Drama
import id.dramakita.app.data.DramaRepository
import id.dramakita.app.ui.components.DramaRowItem

@Composable
fun FavoritesScreen(
    favoriteIds: Set<String>,
    onDramaClick: (Drama) -> Unit,
    onFavoriteClick: (Drama) -> Unit
) {
    val favorites = DramaRepository.dramas.filter { it.id in favoriteIds }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0F15))
            .padding(horizontal = 18.dp)
            .padding(top = 24.dp)
    ) {
        Text("Favoritku", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text("Kumpulan drama yang ingin kamu tonton lagi.", color = Color(0xFFBDBBCB), fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
        if (favorites.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("♡", color = Color(0xFFFF8EAA), fontSize = 52.sp)
                    Text("Belum ada favorit", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 10.dp))
                    Text("Tekan ikon hati pada poster drama untuk menyimpannya di sini.", color = Color(0xFFBDBBCB), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(favorites, key = { it.id }) { drama ->
                    DramaRowItem(
                        drama = drama,
                        isFavorite = true,
                        onClick = { onDramaClick(drama) },
                        onFavoriteClick = { onFavoriteClick(drama) }
                    )
                }
            }
        }
    }
}
