package id.dramakita.app.ui.screens

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import id.dramakita.app.data.Drama
import id.dramakita.app.data.Episode

@Composable
fun PlayerScreen(
    drama: Drama,
    episodeIndex: Int,
    onEpisodeSelected: (Int) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val selectedEpisode: Episode = drama.episodes.getOrElse(episodeIndex) { drama.episodes.first() }
    val exoPlayer = remember(drama.id) { ExoPlayer.Builder(context).build() }
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(true) }
    var hasPlaybackError by remember { mutableStateOf(false) }
    var isOnline by remember { mutableStateOf(hasInternet(context)) }
    val onlineLatest by rememberUpdatedState(isOnline)
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val connectivityManager = remember(context) {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    BackHandler(onBack = onBack)

    DisposableEffect(connectivityManager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                mainHandler.post { isOnline = hasInternet(context) }
            }

            override fun onLost(network: Network) {
                mainHandler.post { isOnline = hasInternet(context) }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val connected = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                mainHandler.post { isOnline = connected }
            }
        }
        runCatching { connectivityManager.registerDefaultNetworkCallback(callback) }
        onDispose {
            runCatching { connectivityManager.unregisterNetworkCallback(callback) }
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) hasPlaybackError = false
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                hasPlaybackError = true
                isBuffering = false
                isPlaying = false
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer, episodeIndex) {
        hasPlaybackError = false
        isBuffering = true
        exoPlayer.setMediaItem(MediaItem.fromUri(selectedEpisode.videoUrl))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { view ->
                view.player = exoPlayer
                view.useController = false
                view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            }
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                .padding(start = 10.dp, end = 18.dp, top = 14.dp, bottom = 28.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        drama.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text("Episode ${selectedEpisode.number} • ${selectedEpisode.title}", color = Color(0xFFE3E0E9), fontSize = 11.sp)
                }
            }
        }

        if (isBuffering && isOnline && !hasPlaybackError) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center).size(48.dp),
                color = Color(0xFFFF5C83),
                strokeWidth = 4.dp
            )
        }

        if (isOnline && !hasPlaybackError) {
            IconButton(
                onClick = {
                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                },
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(68.dp)
                    .background(Color(0x66000000), CircleShape)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Jeda video" else "Putar video",
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        if (!isOnline || hasPlaybackError) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 26.dp)
                    .fillMaxWidth()
                    .background(Color(0xE61A1B24), RoundedCornerShape(20.dp))
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (!isOnline) Icons.Filled.WifiOff else Icons.Filled.Refresh,
                    contentDescription = null,
                    tint = Color(0xFFFF8EAA),
                    modifier = Modifier.size(34.dp)
                )
                Text(
                    text = if (!isOnline) "Tidak ada koneksi internet" else "Video gagal diputar",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
                Text(
                    text = if (!isOnline) "Periksa Wi-Fi atau data seluler, lalu coba lagi." else "Koneksi mungkin lambat atau tautan video sedang tidak tersedia.",
                    color = Color(0xFFC8C6D5),
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Button(
                    onClick = {
                        if (onlineLatest) {
                            hasPlaybackError = false
                            isBuffering = true
                            exoPlayer.setMediaItem(MediaItem.fromUri(selectedEpisode.videoUrl))
                            exoPlayer.prepare()
                            exoPlayer.playWhenReady = true
                        } else {
                            isOnline = hasInternet(context)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5C83)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Coba lagi", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xED080910))))
                .padding(start = 14.dp, end = 14.dp, top = 42.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("DAFTAR EPISODE", color = Color(0xFFFFB4C5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(drama.episodes) { index, episode ->
                    FilterChip(
                        selected = index == episodeIndex,
                        onClick = { onEpisodeSelected(index) },
                        label = { Text("EP ${episode.number}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFF5C83),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xAA242530),
                            labelColor = Color(0xFFF7F5FA)
                        )
                    )
                }
            }
            Text(
                "Video demo: Big Buck Bunny — Blender Foundation, CC BY 3.0",
                color = Color(0xFFD3D0DC),
                fontSize = 9.sp
            )
        }
    }
}

private fun hasInternet(context: Context): Boolean {
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = connectivityManager.activeNetwork ?: return false
    val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
