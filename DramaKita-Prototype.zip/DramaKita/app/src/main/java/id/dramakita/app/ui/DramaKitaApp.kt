package id.dramakita.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import id.dramakita.app.data.Drama
import id.dramakita.app.data.DramaRepository
import id.dramakita.app.data.FavoritesStore
import id.dramakita.app.ui.screens.DetailScreen
import id.dramakita.app.ui.screens.FavoritesScreen
import id.dramakita.app.ui.screens.HomeScreen
import id.dramakita.app.ui.screens.PlayerScreen
import id.dramakita.app.ui.screens.SearchScreen

enum class AppScreen {
    HOME,
    SEARCH,
    FAVORITES,
    DETAIL,
    PLAYER
}

@Composable
fun DramaKitaApp() {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
    var selectedDrama by remember { mutableStateOf(DramaRepository.dramas.first()) }
    var selectedEpisodeIndex by remember { mutableIntStateOf(0) }
    var favoriteIds by remember { mutableStateOf(FavoritesStore.load(context)) }

    fun toggleFavorite(drama: Drama) {
        val updated = if (drama.id in favoriteIds) favoriteIds - drama.id else favoriteIds + drama.id
        favoriteIds = updated
        FavoritesStore.save(context, updated)
    }

    fun openDrama(drama: Drama) {
        selectedDrama = drama
        currentScreen = AppScreen.DETAIL
    }

    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        currentScreen = when (currentScreen) {
            AppScreen.PLAYER -> AppScreen.DETAIL
            AppScreen.DETAIL, AppScreen.SEARCH, AppScreen.FAVORITES -> AppScreen.HOME
            AppScreen.HOME -> AppScreen.HOME
        }
    }

    Scaffold(
        containerColor = Color(0xFF0E0F15),
        bottomBar = {
            if (currentScreen == AppScreen.HOME || currentScreen == AppScreen.SEARCH || currentScreen == AppScreen.FAVORITES) {
                NavigationBar(containerColor = Color(0xFF15161E), contentColor = Color.White) {
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.HOME,
                        onClick = { currentScreen = AppScreen.HOME },
                        icon = { androidx.compose.material3.Icon(Icons.Filled.Home, contentDescription = null) },
                        label = { Text("Beranda", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFF5C83),
                            selectedTextColor = Color(0xFFFF8EAA),
                            indicatorColor = Color(0xFF38212B),
                            unselectedIconColor = Color(0xFF9C99A9),
                            unselectedTextColor = Color(0xFF9C99A9)
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.SEARCH,
                        onClick = { currentScreen = AppScreen.SEARCH },
                        icon = { androidx.compose.material3.Icon(Icons.Filled.Search, contentDescription = null) },
                        label = { Text("Cari", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFF5C83),
                            selectedTextColor = Color(0xFFFF8EAA),
                            indicatorColor = Color(0xFF38212B),
                            unselectedIconColor = Color(0xFF9C99A9),
                            unselectedTextColor = Color(0xFF9C99A9)
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.FAVORITES,
                        onClick = { currentScreen = AppScreen.FAVORITES },
                        icon = { androidx.compose.material3.Icon(Icons.Filled.Favorite, contentDescription = null) },
                        label = { Text("Favorit", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFF5C83),
                            selectedTextColor = Color(0xFFFF8EAA),
                            indicatorColor = Color(0xFF38212B),
                            unselectedIconColor = Color(0xFF9C99A9),
                            unselectedTextColor = Color(0xFF9C99A9)
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFF0E0F15))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                when (currentScreen) {
                    AppScreen.HOME -> HomeScreen(
                        favoriteIds = favoriteIds,
                        onDramaClick = ::openDrama,
                        onFavoriteClick = ::toggleFavorite
                    )
                    AppScreen.SEARCH -> SearchScreen(
                        favoriteIds = favoriteIds,
                        onDramaClick = ::openDrama,
                        onFavoriteClick = ::toggleFavorite
                    )
                    AppScreen.FAVORITES -> FavoritesScreen(
                        favoriteIds = favoriteIds,
                        onDramaClick = ::openDrama,
                        onFavoriteClick = ::toggleFavorite
                    )
                    AppScreen.DETAIL -> DetailScreen(
                        drama = selectedDrama,
                        isFavorite = selectedDrama.id in favoriteIds,
                        onBack = { currentScreen = AppScreen.HOME },
                        onWatch = {
                            selectedEpisodeIndex = 0
                            currentScreen = AppScreen.PLAYER
                        },
                        onFavoriteClick = { toggleFavorite(selectedDrama) }
                    )
                    AppScreen.PLAYER -> PlayerScreen(
                        drama = selectedDrama,
                        episodeIndex = selectedEpisodeIndex,
                        onEpisodeSelected = { selectedEpisodeIndex = it },
                        onBack = { currentScreen = AppScreen.DETAIL }
                    )
                }
            }
        }
    }
}
