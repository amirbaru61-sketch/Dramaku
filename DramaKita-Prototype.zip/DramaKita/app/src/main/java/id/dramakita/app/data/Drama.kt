package id.dramakita.app.data

data class Episode(
    val number: Int,
    val title: String,
    val videoUrl: String
)

data class Drama(
    val id: String,
    val title: String,
    val category: String,
    val synopsis: String,
    val updatedLabel: String,
    val posterEmoji: String,
    val posterStartColor: Long,
    val posterEndColor: Long,
    val episodes: List<Episode>
)
