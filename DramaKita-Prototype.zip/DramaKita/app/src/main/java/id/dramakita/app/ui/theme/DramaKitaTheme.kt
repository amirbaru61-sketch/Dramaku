package id.dramakita.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DramaKitaColors = darkColorScheme(
    primary = Color(0xFFFF5C83),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFFB8A1FF),
    background = Color(0xFF0E0F15),
    onBackground = Color(0xFFF7F5FA),
    surface = Color(0xFF191A23),
    onSurface = Color(0xFFF7F5FA),
    surfaceVariant = Color(0xFF282936),
    onSurfaceVariant = Color(0xFFC8C6D5)
)

@Composable
fun DramaKitaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DramaKitaColors,
        content = content
    )
}
