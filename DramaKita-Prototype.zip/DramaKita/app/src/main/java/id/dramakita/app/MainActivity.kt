package id.dramakita.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import id.dramakita.app.ui.DramaKitaApp
import id.dramakita.app.ui.theme.DramaKitaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent {
            DramaKitaTheme {
                DramaKitaApp()
            }
        }
    }
}
