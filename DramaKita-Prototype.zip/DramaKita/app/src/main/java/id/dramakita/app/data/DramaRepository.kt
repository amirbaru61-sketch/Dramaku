package id.dramakita.app.data

/**
 * Data contoh lokal untuk prototipe. Metadata drama tidak diambil dari server.
 * Semua episode sementara memakai satu video berlisensi terbuka untuk menguji player.
 */
object DramaRepository {
    const val DEMO_VIDEO_URL =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

    private fun episodes(prefix: String, count: Int = 5): List<Episode> =
        (1..count).map { number ->
            Episode(
                number = number,
                title = "$prefix $number",
                videoUrl = DEMO_VIDEO_URL
            )
        }

    val dramas = listOf(
        Drama(
            id = "senja",
            title = "Senja di Ujung Kota",
            category = "Romansa",
            synopsis = "Dua orang asing bertemu setiap sore di halte yang sama. Sebuah pesan yang tertinggal membuat mereka berani membuka cerita lama.",
            updatedLabel = "Baru diperbarui",
            posterEmoji = "🌆",
            posterStartColor = 0xFF5B247A,
            posterEndColor = 0xFF1B1464,
            episodes = episodes("Pertemuan Senja")
        ),
        Drama(
            id = "hujan",
            title = "Janji di Bawah Hujan",
            category = "Drama keluarga",
            synopsis = "Janji masa kecil kembali menguji dua sahabat ketika mereka dipertemukan setelah bertahun-tahun berpisah.",
            updatedLabel = "Episode terbaru",
            posterEmoji = "🌧️",
            posterStartColor = 0xFF134E5E,
            posterEndColor = 0xFF301934,
            episodes = episodes("Janji yang Kembali")
        ),
        Drama(
            id = "rahasia",
            title = "Rahasia Ruang 09",
            category = "Misteri",
            synopsis = "Sebuah nomor kamar yang seharusnya tidak ada menyimpan petunjuk tentang penghuni lama sebuah apartemen.",
            updatedLabel = "Sedang populer",
            posterEmoji = "🚪",
            posterStartColor = 0xFF232526,
            posterEndColor = 0xFF414345,
            episodes = episodes("Pintu yang Terkunci")
        ),
        Drama(
            id = "surat",
            title = "Surat untuk Esok",
            category = "Kehidupan",
            synopsis = "Surat-surat tanpa nama mengubah rutinitas seorang pekerja muda dan membantunya melihat hidup dari arah baru.",
            updatedLabel = "Cerita pilihan",
            posterEmoji = "💌",
            posterStartColor = 0xFFB24592,
            posterEndColor = 0xFF5F0A87,
            episodes = episodes("Surat Rahasia")
        ),
        Drama(
            id = "bintang",
            title = "Saat Bintang Pulang",
            category = "Romansa",
            synopsis = "Seorang musisi yang pulang ke kampung halamannya bertemu lagi dengan orang yang pernah menginspirasi lagu pertamanya.",
            updatedLabel = "Drama terbaru",
            posterEmoji = "✨",
            posterStartColor = 0xFFDA4453,
            posterEndColor = 0xFF89216B,
            episodes = episodes("Melodi Lama")
        )
    )
}
