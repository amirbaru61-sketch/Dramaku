package id.dramakita.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.dramakita.app.data.Drama

@Composable
fun DetailScreen(
    drama: Drama,
    isFavorite: Boolean,
    onBack: () -> Unit,
    onWatch: () -> Unit,
    onFavoriteClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0F15))
            .verticalScroll(rememberScrollState())
            .padding(bottom = 28.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali", tint = Color.White)
            }
            Text("Detail drama", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onFavoriteClick) {
                Icon(
                    imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = if (isFavorite) "Hapus dari favorit" else "Tambah ke favorit",
                    tint = if (isFavorite) Color(0xFFFF5C83) else Color.White
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .height(270.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(drama.posterStartColor.toInt()), Color(drama.posterEndColor.toInt()), Color(0xFF11121A))))
        ) {
            Text(drama.posterEmoji, modifier = Modifier.align(Alignment.Center), fontSize = 100.sp)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6080910))))
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text(drama.category.uppercase(), color = Color(0xFFFFB4C5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(drama.title, color = Color.White, fontSize = 25.sp, lineHeight = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("${drama.episodes.size} episode • ${drama.updatedLabel}", color = Color(0xFFD9D6E1), fontSize = 12.sp)
            }
        }

        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) {
            Text("Sinopsis", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                drama.synopsis,
                modifier = Modifier.padding(top = 9.dp),
                color = Color(0xFFC8C6D5),
                fontSize = 14.sp,
                lineHeight = 22.sp
            )
            Row(modifier = Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoPill(text = drama.category)
                InfoPill(text = "${drama.episodes.size} episode")
            }
            Button(
                onClick = onWatch,
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp).height(54.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5C83), contentColor = Color.White)
            ) {
                Text("▶  Mulai menonton", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "Catatan prototipe: judul dan sinopsis di atas adalah data contoh. Video yang diputar pada tahap ini merupakan cuplikan demo berlisensi terbuka.",
                modifier = Modifier.padding(top = 16.dp),
                color = Color(0xFF8D8B9B),
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun InfoPill(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0xFF272833))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(text, color = Color(0xFFD8D5E2), fontSize = 12.sp)
    }
}
