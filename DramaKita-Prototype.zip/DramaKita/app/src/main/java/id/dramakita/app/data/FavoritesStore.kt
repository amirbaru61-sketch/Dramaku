package id.dramakita.app.data

import android.content.Context

/** Menyimpan ID drama favorit di HP menggunakan SharedPreferences. */
object FavoritesStore {
    private const val PREFS_NAME = "dramakita_local_preferences"
    private const val KEY_FAVORITES = "favorite_drama_ids"

    fun load(context: Context): Set<String> {
        val saved = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getStringSet(KEY_FAVORITES, emptySet())
        return saved?.toSet() ?: emptySet()
    }

    fun save(context: Context, ids: Set<String>) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_FAVORITES, ids.toSet())
            .apply()
    }
}
