package id.dramakita.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.dramakita.app.data.Drama
import id.dramakita.app.data.DramaRepository
import id.dramakita.app.ui.components.DramaPosterCard

@Composable
fun HomeScreen(
    favoriteIds: Set<String>,
    onDramaClick: (Drama) -> Unit,
    onFavoriteClick: (Drama) -> Unit
) {
    val dramas = DramaRepository.dramas
    val featured = dramas.first()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0F15)),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 18.dp,
            end = 18.dp,
            top = 18.dp,
            bottom = 28.dp
        ),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Drama", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Kita", color = Color(0xFFFF5C83), fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                    Box(modifier = Modifier.weight(1f))
                    Text("UNTUKMU ✦", color = Color(0xFFFFA2B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("Cerita singkat, rasa yang panjang.", color = Color(0xFFBDBBCB), fontSize = 14.sp)
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pilihan hari ini", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(248.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(featured.posterStartColor.toInt()), Color(featured.posterEndColor.toInt()), Color(0xFF11121A))
                            )
                        )
                ) {
                    Text(
                        text = featured.posterEmoji,
                        modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp),
                        fontSize = 90.sp
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6080910))))
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text("REKOMENDASI • ${featured.category.uppercase()}", color = Color(0xFFFFB4C5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(featured.title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 27.sp)
                        Text("${featured.episodes.size} episode • ${featured.updatedLabel}", color = Color(0xFFD9D6E1), fontSize = 12.sp)
                        Button(
                            onClick = { onDramaClick(featured) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5C83), contentColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Text("Lihat drama", modifier = Modifier.padding(start = 4.dp), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Drama terbaru", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Box(modifier = Modifier.weight(1f))
                    Text("LIHAT SEMUA", color = Color(0xFFFF8EAA), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dramas) { drama ->
                        DramaPosterCard(
                            drama = drama,
                            isFavorite = drama.id in favoriteIds,
                            onClick = { onDramaClick(drama) },
                            onFavoriteClick = { onFavoriteClick(drama) }
                        )
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Mulai dari suasana", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Romansa, keluarga, misteri, dan kisah kehidupan ada di satu tempat.", color = Color(0xFFBDBBCB), fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
}
