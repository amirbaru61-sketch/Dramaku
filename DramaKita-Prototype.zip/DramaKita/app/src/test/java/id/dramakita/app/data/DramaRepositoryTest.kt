package id.dramakita.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DramaRepositoryTest {
    @Test
    fun sampleDramasHaveTitleEpisodesAndVideoUrls() {
        assertTrue(DramaRepository.dramas.isNotEmpty())
        DramaRepository.dramas.forEach { drama ->
            assertTrue(drama.title.isNotBlank())
            assertTrue(drama.episodes.isNotEmpty())
            drama.episodes.forEach { episode ->
                assertTrue(episode.title.isNotBlank())
                assertTrue(episode.videoUrl.startsWith("https://"))
            }
        }
        assertFalse(DramaRepository.DEMO_VIDEO_URL.isBlank())
    }
}
