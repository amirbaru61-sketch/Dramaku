# Aturan ProGuard untuk prototipe tahap pertama.
# Minifikasi sengaja dinonaktifkan pada build release agar proses awal sederhana.
